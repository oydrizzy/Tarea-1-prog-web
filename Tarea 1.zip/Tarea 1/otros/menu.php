<div class="menu">
        <a href="mi_tarjeta.php">Tarjeta</a>
        <a href="calculadora.php">Calculadora</a>
        <a href="adivina.php">Adivina</a>
        <a href="acerca_de.php">Acerca de mi</a>
    </div>